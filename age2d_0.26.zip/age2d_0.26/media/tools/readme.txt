The program (compiler.exe) launch the AGK compiler which is in your agk folder, and compile your actual project (in C:\Users\YOURNAME\AppData\Local\AGKApps\DracaenaGames\AGE2D\media\scenes\YOURPROJECTNAME).

If you prefer, you can compile your project directly from AGK, it's the same thing. Open the file : YOURPROJECT.agk (YOURPROJECt is the name of your project).


I have put the source of compiler.exe for you to see the code (it's a purebasic code) ;).