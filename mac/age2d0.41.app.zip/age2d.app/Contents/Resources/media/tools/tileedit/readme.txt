Cet outil (tile edit) n'est pas termin�. 
Le d�veloppeur ne pourra �tre tenu responsable des dommages directs ou indirects caus�s sur votre ordinateur.
Vous utilisez cet outil � vos risques et p�rils.