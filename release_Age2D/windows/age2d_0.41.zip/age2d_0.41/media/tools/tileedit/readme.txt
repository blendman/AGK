Cet outil (tileEdit) n'est pas du tout termin�. 
Le d�veloppeur ne pourra �tre tenu responsable des dommages directs ou indirects caus�s sur votre ordinateur.
Vous utilisez cet outil � vos risques et p�rils.